%% section 1.2

clear; clc;

tspan = [0 20];

y0 = [pi/2  0  0  0];

[t,x] = ode45(@(t,x) ode(t,x),tspan,y0);

x11 = 0.5 * sin(x(:,1));
y11 = -0.5 * cos(x(:,1));
x12 = x11 + 0.5 * sin(x(:,2));
y12 = y11 - 0.5 * cos(x(:,2));

for i=1:length(x11)
    plot(x11(i),y11(i),'.r',x12(i),y12(i),'.black');
    line([0 , x11(i)] ,[0 , y11(i)]);
    line([x11(i) , x12(i)] , [y11(i),y12(i)])
    ylim([-1 1]);
    xlim([-1 1]);
    hold off;
    drawnow;
    frame = getframe(gcf);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    if i == 1
        imwrite(imind,cm,'s1.gif','gif','LoopCount',inf);
    else
        imwrite(imind,cm,'s1.gif','gif','DelayTime',0.03,'WriteMode','append');
    end
end
%% section 1.3 & 1.4

clear ; clc;

tspan = [0 20];

% previous initials
y00 = [pi/2  0  0  0];

% new initials with pi/360 shift
y01 = [pi/2+pi/360  pi/360  pi/360  pi/360];

options = odeset('RelTol',1e-6,'AbsTol',1e-6);

[t,x] = ode45(@(t,x) ode(t,x),tspan,y00,options);
[t2,x2]=ode45(@(t2,x2) ode(t2,x2),tspan,y01,options);

x11 = 0.5 * sin(x(:,1));
y11 = -0.5 * cos(x(:,1));
x12 = x11 + 0.5 * sin(x(:,2));
y12 = y11 - 0.5 * cos(x(:,2));

x21 = 0.5 * sin(x2(:,1));
y21 = -0.5 * cos(x2(:,1));
x22 = x21 + 0.5 * sin(x2(:,2));
y22 = y21 - 0.5 * cos(x2(:,2));

for i=1:length(x11)
    plot(x11(i),y11(i),'.r',x12(i),y12(i),'.black');
    line([0 , x11(i)] ,[0 , y11(i)]);
    line([x11(i) , x12(i)] , [y11(i),y12(i)])
    hold on
    plot(x21(i),y21(i),'.r',x22(i),y22(i),'.black');
    line([0 , x21(i)] ,[0 , y21(i)]);
    line([x21(i) , x22(i)] , [y21(i),y22(i)])
    ylim([-1 1]);
    xlim([-1 1]);
    hold off;
    drawnow;
    frame = getframe(1);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    if i == 1
        imwrite(imind,cm,'s3.gif','gif','LoopCount',inf);
    elseif rem(i,2)==0 
        imwrite(imind,cm,'s3.gif','gif','DelayTime',0.02,'WriteMode','append');
    end
end

%% sction 1.5

clc;clear;

tspan = [0 20];

y00 = [pi/4  3*pi/4  0  0];
y01 = [pi/4  0  0  1];
y02 = [0  0  2.5  4];

options = odeset('RelTol',1e-6,'AbsTol',1e-6);

[t,x] = ode45(@(t,x) ode(t,x),tspan,y00,options);
[t,x2]=ode45(@(t,x) ode(t,x),tspan,y01,options);
[t,x3]=ode45(@(t,x) ode(t,x),tspan,y02,options);

x11 = 0.5 * sin(x(:,1));
y11 = -0.5 * cos(x(:,1));
x12 = x11 + 0.5 * sin(x(:,2));
y12 = y11 - 0.5 * cos(x(:,2));

x21 = 0.5 * sin(x2(:,1));
y21 = -0.5 * cos(x2(:,1));
x22 = x21 + 0.5 * sin(x2(:,2));
y22 = y21 - 0.5 * cos(x2(:,2));

x31 = 0.5 * sin(x3(:,1));
y31 = -0.5 * cos(x3(:,1));
x32 = x31 + 0.5 * sin(x3(:,2));
y32 = y31 - 0.5 * cos(x3(:,2));

for i=1:length(x11)

    plot(x11(i),y11(i),'.r',x12(i),y12(i),'.black');
    line([0 , x11(i)] ,[0 , y11(i)]);
    line([x11(i) , x12(i)] , [y11(i),y12(i)])

    hold on

    plot(x21(i),y21(i),'.r',x22(i),y22(i),'.black');
    line([0 , x21(i)] ,[0 , y21(i)]);
    line([x21(i) , x22(i)] , [y21(i),y22(i)])

    plot(x31(i),y31(i),'.r',x32(i),y32(i),'.black');
    line([0 , x31(i)] ,[0 , y31(i)]);
    line([x31(i) , x32(i)] , [y31(i),y32(i)])
    
    ylim([-1 1]);
    xlim([-1 1]);
    hold off;
    drawnow;
    frame = getframe(1);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    if i == 1
        imwrite(imind,cm,'s5.gif','gif','LoopCount',inf);
    elseif rem(i,2)==0 
        imwrite(imind,cm,'s5.gif','gif','DelayTime',0.02,'WriteMode','append');
    end
end

%% section 2.2

clear ; clc ;

a = 1;
t0 = 2;
lambda(a,t0)

L=2;
a = 1;
t0 = 1;
c = 0.1;
syms f(x) ;
f(x) = a - a*abs(x-t0)/t0;
for t=0:10
    fplot(0.5 *(f(x+c*t) + f(x-c*t)))
    xlim([0,2])
    ylim([0,2])
    title( "u(x,t)" )
    drawnow;
    frame = getframe(gcf);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    
    if t==0
        imwrite(imind,cm,'g1.gif','gif','loopcount',inf,'DelayTime',0);
    else
        imwrite(imind,cm,'g1.gif','gif','writemode','append','DelayTime',0);
    end
    pause(0.5)
end

%% section 2.3

% first function

clear ; clc;

L=3;
a = 2;
t0 = L/2;
c = 0.1;
syms f(x) ;
f(x) = a - a*abs(x-t0)/t0;
for t=0:20
    syms g(s) ; 
    g(s) = 1 - 1*abs(s-t0);
    fplot( (0.5 *(f(x+c*t) + f(x-c*t)) ) + int(g(s),x-c*t,x+c*t) )
    xlim([0,3])
    ylim([0,5])
    title( "u(x,t)" )
    drawnow;
    frame = getframe(gcf);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    
    if t==0
        imwrite(imind,cm,'g2.gif','gif','loopcount',inf,'DelayTime',0);
    else
        imwrite(imind,cm,'g2.gif','gif','writemode','append','DelayTime',0);
    end
    pause(0.1)
end

%% section 2.3

% second function

clear ; clc;

a = 2;
c = 0.2;
syms f(x) ;
f(x) = sin(x);
for t=0:60
    syms g(s) ; 
    g(s) = 0.01;
    fplot( (0.5 *(f(x+c*t) + f(x-c*t)) ) + int(g(s),x-c*t,x+c*t) )
    xlim([-10,10])
    ylim([-10,10])
    title( "u(x,t)" )
    drawnow;
    frame = getframe(gcf);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);

    if t==0
        imwrite(imind,cm,'g3.gif','gif','DelayTime',0,'loopcount',inf);
    else
        imwrite(imind,cm,'g3.gif','gif','writemode','append','DelayTime',0);
    end
    pause(0.001)
end

%% section 2.4 

% first part

clear ; clc;

a = 1;
t0 = 1;
syms f(x) ;
f(x) = a - a*abs(x)/t0;
for y=0:40
    fplot(f(x+3*y) + x*f(x+3*y))
    xlim([-10,10])
    ylim([-150,150])
    title( "u(x,t)" )
    drawnow;
    frame = getframe(gcf);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    
    if y==0
        imwrite(imind,cm,'g4.gif','gif','loopcount',inf,'DelayTime',0);
    else
        imwrite(imind,cm,'g4.gif','gif','writemode','append','DelayTime',0);
    end
    pause(0.1)
end

%% section 2.4 

% part 2

clear ; clc;

a = 1;
t0 = 1;
syms f(x) ;
f(x) = a - a*abs(x)/t0;
for y=0:60
    fplot(f(exp(-2i*sqrt(x))-y) + f(exp(2i*sqrt(x))-y))
    xlim([-10,10])
    ylim([-150,10])
    title( "u(x,t)" )
    drawnow;
    frame = getframe(gcf);
    im = frame2im(frame);
    [imind,cm] = rgb2ind(im,256);
    
    if y==0
        imwrite(imind,cm,'g5.gif','gif','loopcount',inf,'DelayTime',0);
    else
        imwrite(imind,cm,'g5.gif','gif','writemode','append','DelayTime',0);
    end
    pause(0.001)
end
%% section 3.2

% defining Bnm function in the functions part of the code(last part)
%% section 3.3 & 3.4

% for 1st function

clear ; clc; 
% a = pi , c = 1

x = 0:0.1:10;
y = x;

t1 = 0;
t2 = 5;
t3 = 10;
t4 = 15;

[X , Y] = meshgrid(x , y);

f1 = @(x,y) cos((pi.*x)./4);

U1 = 0;
U2 = 0;
U3 = 0;
U4 = 0;

for n = 1:1:10
    for m = 1:1:10
        U1 = U1 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t1).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U2 = U2 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t2).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U3 = U3 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t3).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U4 = U4 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t4).*sin(n.*X).*sin(m.*Y);
    end
end

subplot(2,2,1);
surf(X ,Y ,U1);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_1$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,2);
surf(X ,Y ,U2);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_2$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,3);
surf(X ,Y ,U3);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_3$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,4);
surf(X ,Y ,U4);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_4$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');


%% section 3.3 & 3.4

% for 2st function

x = 0:0.1:10;
y = x;

t1 = 0;
t2 = 5;
t3 = 10;
t4 = 15;

[X , Y] = meshgrid(x , y);

f1 = @(x,y) cos((pi.*y)./4);

U1 = 0;
U2 = 0;
U3 = 0;
U4 = 0;

for n = 1:1:10
    for m = 1:1:10
        U1 = U1 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t1).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U2 = U2 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t2).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U3 = U3 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t3).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U4 = U4 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t4).*sin(n.*X).*sin(m.*Y);
    end
end

subplot(2,2,1);
surf(X ,Y ,U1);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_1$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,2);
surf(X ,Y ,U2);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_2$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,3);
surf(X ,Y ,U3);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_3$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,4);
surf(X ,Y ,U4);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_4$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

%% section 3.3 & 3.4

% for 3st function

x = 0:0.1:10;
y = x;

t1 = 0;
t2 = 5;
t3 = 10;
t4 = 15;

[X , Y] = meshgrid(x , y);

f1 = @(x,y) cos((pi.*y.*x)./4);

U1 = 0;
U2 = 0;
U3 = 0;
U4 = 0;

for n = 1:1:10
    for m = 1:1:10
        U1 = U1 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t1).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U2 = U2 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t2).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U3 = U3 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t3).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U4 = U4 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t4).*sin(n.*X).*sin(m.*Y);
    end
end

subplot(2,2,1);
surf(X ,Y ,U1);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_1$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,2);
surf(X ,Y ,U2);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_2$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,3);
surf(X ,Y ,U3);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_3$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,4);
surf(X ,Y ,U4);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_4$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

%% section 3.3 & 3.4

% for 4st function

x = 0:0.1:10;
y = x;

t1 = 0;
t2 = 5;
t3 = 10;
t4 = 15;

[X , Y] = meshgrid(x , y);

f1 = @(x,y) cos((pi.*(y+x))./4);

U1 = 0;
U2 = 0;
U3 = 0;
U4 = 0;

for n = 1:1:10
    for m = 1:1:10
        U1 = U1 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t1).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U2 = U2 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t2).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U3 = U3 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t3).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U4 = U4 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t4).*sin(n.*X).*sin(m.*Y);
    end
end

subplot(2,2,1);
surf(X ,Y ,U1);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_1$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,2);
surf(X ,Y ,U2);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_2$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,3);
surf(X ,Y ,U3);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_3$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,4);
surf(X ,Y ,U4);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_4$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

%% section 3.3 & 3.4

% for 5st function

x = 0:0.1:10;
y = x;

t1 = 0;
t2 = 5;
t3 = 10;
t4 = 15;

[X , Y] = meshgrid(x , y);

f1 = @(x,y) (x-pi./2).^2+(y-pi./2).^2;

U1 = 0;
U2 = 0;
U3 = 0;
U4 = 0;

for n = 1:1:10
    for m = 1:1:10
        U1 = U1 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t1).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U2 = U2 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t2).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U3 = U3 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t3).*sin(n.*X).*sin(m.*Y);
    end
end

for n = 1:1:10
    for m = 1:1:10
        U4 = U4 + Bnm(f1,n,m).*cos(sqrt(n.^2+m^2).*t4).*sin(n.*X).*sin(m.*Y);
    end
end

subplot(2,2,1);
surf(X ,Y ,U1);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_1$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,2);
surf(X ,Y ,U2);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_2$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,3);
surf(X ,Y ,U3);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_3$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

subplot(2,2,4);
surf(X ,Y ,U4);
xlabel('$x$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
ylabel('$y$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
zlabel('$u$' , 'Interpreter' , 'Latex' , 'FontSize' , 20);
title('$t$ $=$ $t_4$' , 'Interpreter' , 'Latex' , 'FontSize' , 20); 
colormap('jet');

%% section 4.1 & 4.2

% function defining for this part is in the functions part(last part in
% file)

clear ; clc;

t = 0:0.1:20;
C=1.5; 
N=1000;
L=100; 

% Define discrete wavenumbers
W = (2*pi/L)*[-N/2:N/2-1];
W = fftshift(W); % Re-order fft wavenumbers

dX=L/N;   
X=-L/2:dX:(L/2)-dX;
U_0 = 0.*X;
U_0((L/2-L/3)/dX:(L/2+L/3)/dX)=1;

[t,u_trans]=ode45(@(t,u_trans)rhsHeat(t,u_trans,W,C),t,fft(U_0));
for i = 1:length(t)
    U(i,:) = ifft(u_trans(i,:));
end

%plot
figure
plot = waterfall(X,t(1:10:end),(U(1:10:end,:)));
set(plot,'LineWidth',1.5,'FaceAlpha',0.1);
colormap(flipud(jet)/1.5)
xlabel('space');
ylabel('time');
zlabel('temperature');

%% section 4.3

figure
xlabel('Space');
ylabel('Temperature');
hold on;
CC = (colormap(jet(10*20)));
dt = 0.1;
for i = 1:10*20
    U(i,:) = ifft(u_trans(i,:));
    if(mod(i-1,10)==0)
        plot(X,U(i,:),'Color',CC(i,:),'LineWidth',1);
        ylim([-1 1.2]);
        hold on, grid on , drawnow
    end
end    

%% section 4.4

clear; clc;
nu=0.001;
L=20; 
C=1;  

N=1000;
dX=L/N;   
X=-L/2:dX:(L/2)-dX;

U_0=sech(X);

W = (2*pi/L)*[-N/2:N/2-1];
W = fftshift(W); 

dt = 0.025;
t = 0:dt:100*dt;
[t,u]=ode45(@(t,u)rhsBurgers(t,u,W,nu),t,U_0);

%plot
figure
plot = waterfall(X,t(1:10:end),real((u(1:10:end,:))));
set(plot,'LineWidth',1.5,'FaceAlpha',0.1);
colormap(flipud(jet)/1.5)
xlabel('space');
ylabel('time');
zlabel('temperature');

%% section 4.5

figure
xlabel('space');
ylabel('temperature');
hold on;
CC = (colormap(jet(100)));
for i = 1:100
    if(mod(i-1,10)==0)
        plot(X,u(i,:),'Color',CC(i,:),'LineWidth',2);
        ylim([-0.5 1.5]);
        hold on, grid on , drawnow
    end
end    
%% functions

function fun = ode(t,x)

g = 9.78 ;

l = 0.5;

m = 2;

dtheta1 = 6/(m * l * l) * (2*x(3) - 3 * cos(x(1) - x(2)) * x(4))/(16-9*(cos(x(1) - x(2))));
dtheta2 = 6/(m * l * l) * (8*x(4) - 3 * cos(x(1) - x(2)) * x(3))/(16-9*(cos(x(1) - x(2))));
dptheta1 = -1/2 * m * l*l * (dtheta1 * dtheta2 * sin(x(1) - x(2)) + 3* g/l * sin(x(1)));
dptheta2 = -1/2 * m * l*l * (-dtheta1 * dtheta2 * sin(x(1) - x(2)) +  g/l * sin(x(2)));

fun = [dtheta1 ; dtheta2 ; dptheta1 ; dptheta2];

end


function transform = rhsHeat(t,u_trans,W,C)
    transform = -C^2*(W.^2)'.*u_trans;
end

function burg = rhsBurgers(t,u,W,nu)
    u_trans = fft(u);
    du = 1i*W'.*u_trans;
    ddu = -(W.^2)'.*u_trans;
    du = ifft(du);
    ddu = ifft(ddu);
    burg = -u.*du+nu*ddu;
end

function bnm = Bnm(f,n,m)

func = @(x,y) f(x,y).*sin(n.*x).*sin(m.*y);
bnm = 4./(pi.^2).*integral2(func,0,pi,0,pi);

end

function lambda(a,t0)
syms f(x) ;
f(x) = a - a*abs(x/t0);
fplot(f)
xlim([-t0,t0])
ylim([0,a])
title( "Lambda(x)" )
end